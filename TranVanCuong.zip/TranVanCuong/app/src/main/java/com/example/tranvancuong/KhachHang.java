package com.example.tranvancuong;

public class KhachHang {


    public int MaKhach;
    public String TenKhach;
    public String DiaChi;
    public String SDT;
    public int getMaKhach() {
        return MaKhach;
    }

    public KhachHang(int maKhach, String tenKhach, String diaChi, String SDT) {
        MaKhach = maKhach;
        TenKhach = tenKhach;
        DiaChi = diaChi;
        this.SDT = SDT;
    }

    public void setMaKhach(int maKhach) {
        MaKhach = maKhach;
    }

    public String getTenKhach() {
        return TenKhach;
    }

    public void setTenKhach(String tenKhach) {
        TenKhach = tenKhach;
    }

    public String getDiaChi() {
        return DiaChi;
    }

    public void setDiaChi(String diaChi) {
        DiaChi = diaChi;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

}
