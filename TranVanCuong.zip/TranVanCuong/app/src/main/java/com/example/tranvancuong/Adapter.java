package com.example.tranvancuong;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class Adapter extends BaseAdapter {

    ArrayList<KhachHang> khachHangs;
    public Adapter(ArrayList<KhachHang> khachHangs) {
        this.khachHangs = khachHangs;
    }
    @Override
    public int getCount() {
        return khachHangs.size();
    }

    @Override
    public Object getItem(int position) {
        return khachHangs.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view;
        if (convertView == null){
            view = View.inflate(parent.getContext(), R.layout.item_view, null);
        }
        else {
            view = convertView;
        }
        KhachHang khachHang1 = khachHangs.get(position);

        //ánh xạ
        TextView TenKhach = view.findViewById(R.id.Name);
        TextView SDT = view.findViewById(R.id.phone);
        ImageView img = view.findViewById(R.id.imageView);

        TenKhach.setText(khachHang1.getTenKhach());
        SDT.setText(khachHang1.getSDT());
        img.setImageResource(R.drawable.thuan);
        return view;
    }
}
