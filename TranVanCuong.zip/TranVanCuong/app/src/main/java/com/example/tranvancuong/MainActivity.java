package com.example.tranvancuong;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText MaKhach, TenKhach, DiaCHi, SDTT;
    Button Them, Sua, Xoa, HienThi;

    ListView LV;
    SQLiteDatabase database;
    ArrayList<KhachHang> arrayList = new ArrayList<>();
    int idUpdate, idDel;
    int vitri;

    Adapter adaapter;
    Adapter adapter = new Adapter(arrayList);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TenKhach = findViewById(R.id.TenK);
        DiaCHi =findViewById(R.id.DiaChi);
        SDTT = findViewById(R.id.SDT);
        Them =findViewById(R.id.BTThem);
        Sua = findViewById(R.id.BTSua);
        Xoa =findViewById(R.id.BTXoa);
        LV = findViewById(R.id.List_View);
        LV.setAdapter(adapter);

        TaoCSDL();
        HienThi();

        LV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                idUpdate = arrayList.get(position).getMaKhach();
                TenKhach.setText(arrayList.get(position).getTenKhach());
                DiaCHi.setText(arrayList.get(position).getDiaChi());
                SDTT.setText(arrayList.get(position).getSDT());
                vitri = position;
            }
        });

        Them.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String TK = TenKhach.getText().toString();
                String DC = DiaCHi.getText().toString();
                String SDT1 = SDTT.getText().toString();
                String sql = "INSERT INTO KH1(TenK, DiaChi, SDT) VALUES ('" + TK + "','" + DC + "','" + SDT1 + "')";
                database.execSQL(sql);
                HienThi();
            }
        });

        Sua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String TK = TenKhach.getText().toString();
                String DC = DiaCHi.getText().toString();
                String SDT1 = SDTT.getText().toString();
                String sql = "UPDATE KH1 SET TenK = '" + TK + "', DiaChi = '" + DC + "', SDT = '" + SDT1 + "' WHERE MaK = " + idUpdate ;
                database.execSQL(sql);
                HienThi();
            }
        });

        Xoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                idDel = arrayList.get(vitri).getMaKhach();
                String sql = "Delete from KH1 where MaK = " + idDel;
                database.execSQL(sql);
                HienThi();
            }
        });
    }

    public void HienThi(){
        if(arrayList.size() !=0){
            arrayList.clear();
        }

        String sql = "Select * from KH1";
        Cursor cs = database.rawQuery(sql, null);
        cs.moveToNext();
        while (!cs.isAfterLast()){
            int Ma = cs.getInt(0);
            String Ten = cs.getString(1);
            String Dc = cs.getString(2);
            String So = cs.getString( 3);
            arrayList.add(new KhachHang(Ma, Ten, Dc, So));
            cs.moveToNext();

        }
        adapter.notifyDataSetChanged();

    }

    public void TaoCSDL(){
        database = openOrCreateDatabase("QLKH.db", MODE_PRIVATE, null);
        String Sql = "Create Table if not Exists KH1(MaK integer primary key autoincrement, TenK text, DiaChi text, SDT text)";
        database.execSQL(Sql);
    }
}